"""
Claudinei de Oliveira - encode: pt-br - data: 14-02-2023
Tkinter - rotinas de verificação entre outras
controller.py
"""

